# pill-detection > 2025-10-24 6:52pm
https://universe.roboflow.com/codeitteam7/pill-detection-yy0ui

Provided by a Roboflow user
License: CC BY 4.0

